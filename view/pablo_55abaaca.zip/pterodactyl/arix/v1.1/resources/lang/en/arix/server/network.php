<?php

return[
    'network' => 'Network',
    'manage-allocation' => 'Manage allocation',
    'create-allocation' => 'Create Allocation',
    'currently-using' => 'You are currently using {{current}} of {{max}} allowed allocations for this server.',

    'IP' => 'IP',
    'port' => 'Port',
    'notes' => 'Notes',
    'primary' => 'Primary',
    'make-primary' => 'Make Primary',

    'remove-allocation' => 'Remove Allocation',
    'remove-allocation-description' => 'This allocation will be immediately removed from your server.',
    'delete' => 'Delete'
];